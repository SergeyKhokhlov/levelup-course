print("Ура")
print("Ура")
print("Ура")
