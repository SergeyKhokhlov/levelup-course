a = input()
if "наушники" in a or "кофе" in a or "ягоды" in a or "ноутбук" in a:
    print("Попалось")
else:
    print("Слова нет! Ищем дальше!")
