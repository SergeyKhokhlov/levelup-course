a = input()
if a == "Да":
    print("Нет")
else:
    print("Да")
