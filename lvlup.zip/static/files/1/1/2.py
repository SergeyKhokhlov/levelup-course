a = input()
b = input()
if a > b:
    print("Не хватает средств")
else:
    print("Оплачено")