a = input()
print(a)