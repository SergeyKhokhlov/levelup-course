a = input()
b = input()
if a == b:
    print("Числа равны")
elif a > b:
    print("Первое больше")
elif a < b:
    print("Второе больше")